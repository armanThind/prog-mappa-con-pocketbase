import './style.css'
const response = await fetch("http://127.0.0.1:8090/api/collections/appunti/records")
const data = await response.json()
console.log(data)
let marker = L.marker([5000, 0])
const map = L.map('map').setView([35,20], 3);
const btn1 = document.getElementById("bottone1")
const btn2 = document.getElementById("bottone2")
const btn3 = document.getElementById("bottone3")
let a = false
let k = false
let z
let array_pieno = await prendi_dati()
let ultimo_val_array = array_pieno.pop()
if (ultimo_val_array == undefined) {
  z = 0
}
else {
  z = ultimo_val_array.group + 1
}
L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
  maxZoom: 19,
  minZoom: 2,
  attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
}).addTo(map);
mostra_tutto()
async function prendi_dati() {
  const response = await fetch("http://127.0.0.1:8090/api/collections/appunti/records?page=1&perPage=2000");
  const data = await response.json();
  let oggetto = data.items
  console.log(oggetto)
  return oggetto;
}

async function onMapClick(e) {
  if (a == true) {
    marker.setLatLng(e.latlng).addTo(map);
    let x = e.latlng.lat
    let y = e.latlng.lng
    let coordinate = { "lon": x, "lat": y }
    console.log(coordinate)
    console.log(z)
    fetch("http://127.0.0.1:8090/api/collections/appunti/records", {
      method: "POST",
      body: JSON.stringify({
        lat: x,
        lon: y,
        group: z
      }),
      headers: {
        "Content-Type": "application/json"
      }
    })
    fetch("http://127.0.0.1:8090/api/collections/appunti/records")
      .then(r => {
        return r.json();
      }).then((data) => {
        console.log(data)
      })
  }

}
btn3.onclick = async () => {
  if (a == true) {
    a = false
    btn1.style.backgroundColor = "";
    map.removeLayer(marker)
  }
  if (k == false) {
    k = true
    btn3.style.backgroundColor = "white"
    btn3.style.color = "red"
    console.log("modalità elimina attivata")
  }
  else if (k == true) {
    k = false
    btn3.style.backgroundColor = ""
    btn3.style.color = ""
    console.log("modalità elimina disattivata")
  }
}
btn1.onclick = async () => {
  if (k == true) {
    k = false
    btn3.style.backgroundColor = ""
    btn3.style.color = ""
    console.log("modalità elimina disattivata")
  }
  if (a == true) {
    a = false
    btn1.style.backgroundColor = "";
    map.removeLayer(marker)
  }
  else if (a == false) {
    a = true
    btn1.style.backgroundColor = "greenyellow"
    console.log("premuto2")
    marker.trasparent = false
    marker.setLatLng([5000, 0]).addTo(map);
    map.addLayer(marker)
  }
}
btn2.onclick = async () => {
  if (a == true) {
    a = false
    btn1.style.backgroundColor = "";
    map.removeLayer(marker)
  }
  if (k == true) {
    k = false
    btn3.style.backgroundColor = ""
    btn3.style.color = ""
    console.log("modalità elimina disattivata")
  }
  let latlon = []
  let dati_imp = []
  let dati = await prendi_dati();
  dati.push(0)
  dati.forEach((elem) =>
    dati_imp.push([elem.lat, elem.lon, elem.group])
  )
  console.log("gruppo più grosso:")
  console.log("z")
  console.log(z)

  dati_imp.forEach((elem) => {
    console.log(elem[2])
    if (elem[2] == z) {
      latlon.push([elem[0], elem[1]])
      console.log("non filtrato!")
    }
    else { console.log("elemento filtrato!") }
  }
  )
  let forma = L.polygon(latlon, { color: colorerandom() }).addTo(map);
  // attach click handler to this polygon
  forma.on('click', formaonclick);
  if (latlon.length > 0) {
    console.log("aggiungo!!")
    forma.info = z
    console.log("info segreta nascosta:")
    console.log(forma.info)
    z = z + 1
    latlon = []
  }

  // console.log(latlon)

}
map.on('click', onMapClick);

async function mostra_tutto() {
  let latlon2 = []
  let dati_imp2 = []
  let dati2 = await prendi_dati();
  dati2.push(0)
  dati2.forEach((elem) =>
    dati_imp2.push([elem.lat, elem.lon, elem.group])
  )
  for (let i = z; i >= 0; i--) {
    dati_imp2.forEach((elem) => {
      console.log(elem[2])
      if (elem[2] == i) {
        latlon2.push([elem[0], elem[1]])
        console.log("non filtrato!")
      } //else { console.log("elemento filtrato!") }
    }
    )
    let forma = L.polygon(latlon2, { color: colorerandom() }).addTo(map);
    forma.on('click', formaonclick);
    if (latlon2.length > 0) {
      console.log("aggiungo!!")
      forma.info = i
      latlon2 = []
    }
  }
}

function colorerandom() {
  return `#${Math.floor(Math.random() * 16777215).toString(16).padStart(6, '0')}`;
}
async function formaonclick(e) {
  if (k == true) {
    let userResponse = confirm("attento! stai per eliminare un elemento. Sei sicuro di voler procedere?");
    if (userResponse) {
      console.log("confermata eliminazione");
      console.log(e?.target?.info)  // e.target è il poligono cliccato
      map.removeLayer(e?.target)
      let dati = await prendi_dati();
      dati.forEach(async (elem) => {
        console.log(" gruppo da eliminare:")
        console.log(e?.target?.info)
        if (elem.group == e?.target?.info) {
          console.log("eliminato elemento con gruppo:")
          console.log(elem.group)
          await fetch(`http://127.0.0.1:8090/api/collections/appunti/records/${elem.id}`, {
            method: "delete",
            headers: { "content-type": "application/json" },
          });
        }
      })
    }
  }
  else {
    console.log("modalità elimina non attivata")
  }
}

